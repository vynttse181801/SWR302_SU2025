import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

export const FAQ = () => {
  const faqs = [
    {
      id: 1,
      question: "What services do you offer for HIV treatment?",
      answer: "We provide comprehensive HIV care including testing, diagnosis, antiretroviral therapy, medication management, adherence support, regular monitoring, mental health services, nutrition counseling, and case management to connect you with additional resources."
    },
    {
      id: 2,
      question: "Is my information kept confidential?",
      answer: "Absolutely. We maintain strict confidentiality of all patient information in accordance with HIPAA regulations. Your privacy is our priority, and we have secure systems in place to protect your medical records and personal information."
    },
    {
      id: 3,
      question: "What should I bring to my first appointment?",
      answer: "Please bring your ID, insurance card, a list of current medications, medical records if available, and any questions you have. If you're transferring care, bringing records of your previous HIV treatment and lab results is very helpful."
    },
    {
      id: 4,
      question: "Do you offer PrEP (Pre-Exposure Prophylaxis) services?",
      answer: "Yes, we provide comprehensive PrEP services including evaluation, prescriptions, regular testing, and ongoing monitoring. Our team will help determine if PrEP is right for you and support you throughout the process."
    },
    {
      id: 5,
      question: "How often will I need to come in for appointments?",
      answer: "The frequency of appointments varies based on individual needs. Typically, patients starting treatment visit more frequently (every 1-3 months) until their condition stabilizes. Once stable on treatment with an undetectable viral load, visits may be spaced to every 3-6 months."
    },
    {
      id: 6,
      question: "What insurance plans do you accept?",
      answer: "We accept most major insurance plans, Medicare, and Medicaid. We also have financial counselors who can help uninsured patients access medication assistance programs and other resources to ensure you receive the care you need."
    },
    {
      id: 7,
      question: "Do you offer telehealth appointments?",
      answer: "Yes, we offer telehealth appointments for many types of visits, including follow-ups, medication reviews, and counseling sessions. In-person visits are required for certain services like lab work and initial consultations."
    },
    {
      id: 8,
      question: "What support groups do you offer?",
      answer: "We facilitate several support groups including newly diagnosed patients, long-term survivors, youth groups, and groups for specific populations. Groups meet both in-person and virtually to provide emotional support and community connection."
    }
  ];
  
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  
  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">Frequently Asked Questions</h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            Find answers to common questions about our services, appointments, and HIV care. If you don't see your question here, please contact us.
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div 
                key={faq.id} 
                className="bg-white rounded-xl shadow-sm overflow-hidden"
              >
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full px-6 py-4 text-left flex justify-between items-center focus:outline-none"
                >
                  <span className="font-medium text-gray-800">{faq.question}</span>
                  {openIndex === index ? (
                    <ChevronUp className="w-5 h-5 text-blue-600" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-400" />
                  )}
                </button>
                
                {openIndex === index && (
                  <div className="px-6 pb-4">
                    <p className="text-gray-600">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
          
          <div className="mt-10 bg-blue-50 rounded-xl p-6 text-center">
            <h3 className="text-lg font-medium text-gray-800 mb-2">Still have questions?</h3>
            <p className="text-gray-600 mb-4">
              Our team is here to provide the information you need.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="tel:+12125557890" 
                className="inline-flex items-center justify-center bg-white border border-gray-300 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-50 transition-colors font-medium"
              >
                Call Us
              </a>
              <a 
                href="#contact-form" 
                className="inline-flex items-center justify-center bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium"
              >
                Send a Message
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};