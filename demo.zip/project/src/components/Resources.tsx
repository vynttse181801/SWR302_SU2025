import React, { useState } from 'react';
import { BookOpen, FileText, Video, Download } from 'lucide-react';

export const Resources = () => {
  const [activeTab, setActiveTab] = useState('education');
  
  const tabContent = {
    education: [
      {
        id: 1,
        title: "Understanding HIV Treatment",
        description: "A comprehensive guide to antiretroviral therapy and how it works to manage HIV.",
        icon: <BookOpen className="w-5 h-5" />,
        link: "#resource1"
      },
      {
        id: 2,
        title: "Living Well with HIV",
        description: "Practical advice for maintaining your health and wellness while living with HIV.",
        icon: <BookOpen className="w-5 h-5" />,
        link: "#resource2"
      },
      {
        id: 3,
        title: "Nutrition and HIV",
        description: "Learn about the important role nutrition plays in supporting your immune system.",
        icon: <FileText className="w-5 h-5" />,
        link: "#resource3"
      },
      {
        id: 4,
        title: "HIV Prevention Methods",
        description: "An overview of different strategies to prevent HIV transmission.",
        icon: <FileText className="w-5 h-5" />,
        link: "#resource4"
      }
    ],
    videos: [
      {
        id: 1,
        title: "How Antiretroviral Therapy Works",
        description: "A visual explanation of how HIV medications work in your body.",
        icon: <Video className="w-5 h-5" />,
        link: "#video1"
      },
      {
        id: 2,
        title: "Patient Stories: Living Positively",
        description: "Real stories from individuals thriving while managing HIV.",
        icon: <Video className="w-5 h-5" />,
        link: "#video2"
      },
      {
        id: 3,
        title: "Understanding Your Lab Results",
        description: "A guide to interpreting your HIV-related lab tests and what they mean.",
        icon: <Video className="w-5 h-5" />,
        link: "#video3"
      }
    ],
    downloads: [
      {
        id: 1,
        title: "Medication Adherence Calendar",
        description: "A printable calendar to help track your medication schedule.",
        icon: <Download className="w-5 h-5" />,
        link: "#download1"
      },
      {
        id: 2,
        title: "HIV and Your Rights Guide",
        description: "Information about legal protections and rights for people living with HIV.",
        icon: <Download className="w-5 h-5" />,
        link: "#download2"
      },
      {
        id: 3,
        title: "Nutrition and Recipe Guide",
        description: "Healthy recipes and meal planning specific to supporting immune health.",
        icon: <Download className="w-5 h-5" />,
        link: "#download3"
      },
      {
        id: 4,
        title: "Community Resources Directory",
        description: "A comprehensive list of local and national support services.",
        icon: <Download className="w-5 h-5" />,
        link: "#download4"
      }
    ]
  };

  return (
    <section id="resources" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">Educational Resources</h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            Access our library of resources designed to help you understand HIV, treatment options, and strategies for living a healthy life.
          </p>
        </div>
        
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="border-b border-gray-200">
            <nav className="flex">
              <button
                onClick={() => setActiveTab('education')}
                className={`px-6 py-4 text-sm font-medium ${
                  activeTab === 'education'
                    ? 'border-b-2 border-blue-600 text-blue-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Educational Materials
              </button>
              <button
                onClick={() => setActiveTab('videos')}
                className={`px-6 py-4 text-sm font-medium ${
                  activeTab === 'videos'
                    ? 'border-b-2 border-blue-600 text-blue-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Video Resources
              </button>
              <button
                onClick={() => setActiveTab('downloads')}
                className={`px-6 py-4 text-sm font-medium ${
                  activeTab === 'downloads'
                    ? 'border-b-2 border-blue-600 text-blue-600'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                Downloadable Tools
              </button>
            </nav>
          </div>
          
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {tabContent[activeTab].map((item) => (
                <a
                  key={item.id}
                  href={item.link}
                  className="flex items-start p-4 rounded-lg hover:bg-blue-50 transition-colors"
                >
                  <div className="flex-shrink-0 w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-800">{item.title}</h3>
                    <p className="mt-1 text-gray-600">{item.description}</p>
                  </div>
                </a>
              ))}
            </div>
            
            <div className="mt-6 text-center">
              <a
                href="#resource-library"
                className="inline-flex items-center text-blue-600 hover:text-blue-800 font-medium"
              >
                View full resource library →
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};