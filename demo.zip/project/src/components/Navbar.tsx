import React, { useState, useEffect } from 'react';
import { Phone, Menu, X, User } from 'lucide-react';

export const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <span className="text-2xl font-bold text-blue-600">
              HIV<span className="text-teal-600">Care</span>
            </span>
          </div>
          
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#services" className="text-gray-700 hover:text-blue-600 transition-colors">
              Services
            </a>
            <a href="#resources" className="text-gray-700 hover:text-blue-600 transition-colors">
              Resources
            </a>
            <a href="#appointment" className="text-gray-700 hover:text-blue-600 transition-colors">
              Appointments
            </a>
            <a href="#team" className="text-gray-700 hover:text-blue-600 transition-colors">
              Our Team
            </a>
            <a href="#faq" className="text-gray-700 hover:text-blue-600 transition-colors">
              FAQs
            </a>
          </nav>
          
          <div className="flex items-center space-x-4">
            <a
              href="tel:+1800HIVHELP"
              className="hidden md:flex items-center text-sm font-medium text-red-600 hover:text-red-700"
            >
              <Phone className="w-4 h-4 mr-1" />
              Emergency: 1-800-HIV-HELP
            </a>
            
            <a
              href="#patient-portal"
              className="hidden md:flex items-center bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-full transition-colors"
            >
              <User className="w-4 h-4 mr-2" />
              Patient Portal
            </a>
            
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-gray-700 focus:outline-none"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg absolute w-full">
          <div className="container mx-auto px-4 py-4">
            <nav className="flex flex-col space-y-4">
              <a
                href="#services"
                className="text-gray-700 hover:text-blue-600 transition-colors py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Services
              </a>
              <a
                href="#resources"
                className="text-gray-700 hover:text-blue-600 transition-colors py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Resources
              </a>
              <a
                href="#appointment"
                className="text-gray-700 hover:text-blue-600 transition-colors py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Appointments
              </a>
              <a
                href="#team"
                className="text-gray-700 hover:text-blue-600 transition-colors py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Our Team
              </a>
              <a
                href="#faq"
                className="text-gray-700 hover:text-blue-600 transition-colors py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                FAQs
              </a>
              <div className="pt-2 border-t border-gray-200">
                <a
                  href="tel:+1800HIVHELP"
                  className="flex items-center text-sm font-medium text-red-600 hover:text-red-700 py-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <Phone className="w-4 h-4 mr-1" />
                  Emergency: 1-800-HIV-HELP
                </a>
                <a
                  href="#patient-portal"
                  className="flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-full transition-colors mt-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <User className="w-4 h-4 mr-2" />
                  Patient Portal
                </a>
              </div>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};