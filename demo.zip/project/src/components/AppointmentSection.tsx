import React, { useState } from 'react';
import { Calendar, Clock, MapPin, Phone } from 'lucide-react';

export const AppointmentSection = () => {
  const [appointmentType, setAppointmentType] = useState('initial');
  
  return (
    <section id="appointment" className="py-16 bg-gradient-to-br from-blue-600 to-blue-800 text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Schedule Your Appointment</h2>
          <p className="max-w-3xl mx-auto opacity-90">
            Our care team is ready to provide the support and treatment you need. 
            Schedule an appointment at our clinic or via telehealth.
          </p>
        </div>
        
        <div className="bg-white rounded-xl shadow-xl overflow-hidden text-gray-800">
          <div className="grid grid-cols-1 lg:grid-cols-3">
            <div className="lg:col-span-2 p-8">
              <h3 className="text-xl font-semibold mb-6">Book Your Visit</h3>
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Type of Appointment
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <button
                    onClick={() => setAppointmentType('initial')}
                    className={`px-4 py-3 rounded-lg border transition-colors ${
                      appointmentType === 'initial'
                        ? 'bg-blue-50 border-blue-600 text-blue-700'
                        : 'border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    Initial Consultation
                  </button>
                  <button
                    onClick={() => setAppointmentType('followup')}
                    className={`px-4 py-3 rounded-lg border transition-colors ${
                      appointmentType === 'followup'
                        ? 'bg-blue-50 border-blue-600 text-blue-700'
                        : 'border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    Follow-up Visit
                  </button>
                  <button
                    onClick={() => setAppointmentType('testing')}
                    className={`px-4 py-3 rounded-lg border transition-colors ${
                      appointmentType === 'testing'
                        ? 'bg-blue-50 border-blue-600 text-blue-700'
                        : 'border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    Testing Only
                  </button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                    Full Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter your name"
                  />
                </div>
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="(000) 000-0000"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="your@email.com"
                  />
                </div>
                <div>
                  <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-2">
                    Preferred Date
                  </label>
                  <input
                    type="date"
                    id="date"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Preferred Time
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {['Morning', 'Afternoon', 'Evening', 'Any Time'].map((time) => (
                    <label key={time} className="flex items-center space-x-2 border rounded-lg p-3 cursor-pointer hover:bg-gray-50">
                      <input type="radio" name="time" className="h-4 w-4 text-blue-600" />
                      <span>{time}</span>
                    </label>
                  ))}
                </div>
              </div>
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Appointment Method
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <label className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-gray-50">
                    <input type="radio" name="method" className="h-4 w-4 text-blue-600" />
                    <div className="flex items-center">
                      <MapPin className="h-5 w-5 text-blue-600 mr-2" />
                      <span>In-person Visit</span>
                    </div>
                  </label>
                  <label className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-gray-50">
                    <input type="radio" name="method" className="h-4 w-4 text-blue-600" />
                    <div className="flex items-center">
                      <Phone className="h-5 w-5 text-teal-600 mr-2" />
                      <span>Telehealth</span>
                    </div>
                  </label>
                </div>
              </div>
              
              <div>
                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-6 rounded-lg font-medium transition-colors">
                  Request Appointment
                </button>
                <p className="text-sm text-gray-500 mt-2 text-center">
                  We'll contact you within 24 hours to confirm your appointment.
                </p>
              </div>
            </div>
            
            <div className="bg-blue-50 p-8">
              <h3 className="text-xl font-semibold mb-6">Clinic Information</h3>
              
              <div className="space-y-6">
                <div>
                  <h4 className="font-medium text-gray-700 mb-2 flex items-center">
                    <MapPin className="w-5 h-5 mr-2 text-blue-600" />
                    Location
                  </h4>
                  <p className="text-gray-600">
                    123 Healthcare Avenue<br />
                    Medical Center, Suite 300<br />
                    New York, NY 10001
                  </p>
                </div>
                
                <div>
                  <h4 className="font-medium text-gray-700 mb-2 flex items-center">
                    <Clock className="w-5 h-5 mr-2 text-blue-600" />
                    Clinic Hours
                  </h4>
                  <div className="text-gray-600 space-y-1">
                    <p>Monday - Friday: 8:00 AM - 6:00 PM</p>
                    <p>Saturday: 9:00 AM - 1:00 PM</p>
                    <p>Sunday: Closed</p>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium text-gray-700 mb-2 flex items-center">
                    <Phone className="w-5 h-5 mr-2 text-blue-600" />
                    Contact
                  </h4>
                  <div className="text-gray-600 space-y-1">
                    <p>Phone: (212) 555-7890</p>
                    <p>Emergency: 1-800-HIV-HELP</p>
                    <p>Email: care@hivtreatment.org</p>
                  </div>
                </div>
                
                <div className="pt-4 border-t border-gray-200">
                  <h4 className="font-medium text-gray-700 mb-2">Same-Day Appointments</h4>
                  <p className="text-gray-600 mb-4">
                    Need to be seen today? Call our urgent appointment line for same-day options.
                  </p>
                  <a
                    href="tel:+12125557890"
                    className="inline-flex items-center font-medium text-blue-600 hover:text-blue-800"
                  >
                    <Phone className="w-4 h-4 mr-2" />
                    (212) 555-7890
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};