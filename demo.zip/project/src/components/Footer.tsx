import React from 'react';
import { Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="mb-4">
              <span className="text-2xl font-bold">
                HIV<span className="text-teal-400">Care</span>
              </span>
            </div>
            <p className="text-gray-400 mb-4">
              Providing comprehensive, compassionate care for individuals living with HIV since 1995.
            </p>
            <div className="flex space-x-4">
              <a href="#facebook" className="text-gray-400 hover:text-white transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#twitter" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#instagram" className="text-gray-400 hover:text-white transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#youtube" className="text-gray-400 hover:text-white transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="#services" className="text-gray-400 hover:text-white transition-colors">
                  Our Services
                </a>
              </li>
              <li>
                <a href="#resources" className="text-gray-400 hover:text-white transition-colors">
                  Resources
                </a>
              </li>
              <li>
                <a href="#appointment" className="text-gray-400 hover:text-white transition-colors">
                  Book Appointment
                </a>
              </li>
              <li>
                <a href="#patient-portal" className="text-gray-400 hover:text-white transition-colors">
                  Patient Portal
                </a>
              </li>
              <li>
                <a href="#team" className="text-gray-400 hover:text-white transition-colors">
                  Meet Our Team
                </a>
              </li>
              <li>
                <a href="#careers" className="text-gray-400 hover:text-white transition-colors">
                  Careers
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <a href="#living-with-hiv" className="text-gray-400 hover:text-white transition-colors">
                  Living with HIV
                </a>
              </li>
              <li>
                <a href="#medication" className="text-gray-400 hover:text-white transition-colors">
                  Medication Information
                </a>
              </li>
              <li>
                <a href="#support-groups" className="text-gray-400 hover:text-white transition-colors">
                  Support Groups
                </a>
              </li>
              <li>
                <a href="#prevention" className="text-gray-400 hover:text-white transition-colors">
                  HIV Prevention
                </a>
              </li>
              <li>
                <a href="#research" className="text-gray-400 hover:text-white transition-colors">
                  Research & Clinical Trials
                </a>
              </li>
              <li>
                <a href="#faq" className="text-gray-400 hover:text-white transition-colors">
                  FAQs
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="w-5 h-5 text-teal-400 mr-2 mt-0.5" />
                <span className="text-gray-400">
                  123 Healthcare Avenue<br />
                  Medical Center, Suite 300<br />
                  New York, NY 10001
                </span>
              </li>
              <li className="flex items-center">
                <Phone className="w-5 h-5 text-teal-400 mr-2" />
                <a href="tel:+12125557890" className="text-gray-400 hover:text-white transition-colors">
                  (212) 555-7890
                </a>
              </li>
              <li className="flex items-center">
                <Mail className="w-5 h-5 text-teal-400 mr-2" />
                <a href="mailto:care@hivtreatment.org" className="text-gray-400 hover:text-white transition-colors">
                  care@hivtreatment.org
                </a>
              </li>
            </ul>
            <div className="mt-6">
              <p className="text-gray-400 font-medium">Emergency Support</p>
              <a href="tel:+18004448888" className="text-red-400 hover:text-red-300 transition-colors font-semibold">
                1-800-HIV-HELP (448-4357)
              </a>
            </div>
          </div>
        </div>
        
        <div className="pt-8 border-t border-gray-800 text-center md:flex md:justify-between md:items-center">
          <p className="text-gray-400 mb-4 md:mb-0">
            © 2025 HIV Treatment and Medical Services. All rights reserved.
          </p>
          <div className="space-x-4">
            <a href="#privacy" className="text-gray-400 hover:text-white transition-colors text-sm">
              Privacy Policy
            </a>
            <a href="#terms" className="text-gray-400 hover:text-white transition-colors text-sm">
              Terms of Service
            </a>
            <a href="#accessibility" className="text-gray-400 hover:text-white transition-colors text-sm">
              Accessibility
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};