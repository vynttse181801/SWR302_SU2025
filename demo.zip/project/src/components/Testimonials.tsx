import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';

export const Testimonials = () => {
  const testimonials = [
    {
      id: 1,
      quote: "The care team has been an amazing support system. They don't just treat my HIV; they care for me as a whole person.",
      author: "Patient, 42",
      duration: "Patient for 5 years"
    },
    {
      id: 2,
      quote: "I was afraid when I first got diagnosed, but the staff made me feel comfortable and hopeful. The education they provided helped me understand that I can live a normal, healthy life.",
      author: "Patient, 29",
      duration: "Patient for 2 years"
    },
    {
      id: 3,
      quote: "The clinic's approach to privacy and confidentiality gave me the confidence to seek help. Their telehealth options have made it so much easier to stick with my treatment plan.",
      author: "Patient, 35",
      duration: "Patient for 3 years"
    }
  ];
  
  const [currentIndex, setCurrentIndex] = useState(0);
  
  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };
  
  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section className="py-16 bg-teal-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">Patient Stories</h2>
            <p className="text-gray-600">
              Hear from individuals who have found support and care through our services.
              All testimonials are shared with permission and respect for privacy.
            </p>
          </div>
          
          <div className="bg-white rounded-xl shadow-md p-8 md:p-10 relative">
            <div className="absolute top-8 left-8 md:top-10 md:left-10">
              <Quote className="w-12 h-12 text-teal-100" />
            </div>
            
            <div className="pt-10 pb-4">
              <p className="text-xl md:text-2xl text-gray-700 italic relative z-10">
                "{testimonials[currentIndex].quote}"
              </p>
              
              <div className="mt-6">
                <p className="font-medium text-gray-800">{testimonials[currentIndex].author}</p>
                <p className="text-gray-500 text-sm">{testimonials[currentIndex].duration}</p>
              </div>
            </div>
            
            <div className="flex justify-between items-center mt-6">
              <div className="flex space-x-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`w-3 h-3 rounded-full ${
                      index === currentIndex ? 'bg-teal-600' : 'bg-gray-200'
                    }`}
                    aria-label={`Go to testimonial ${index + 1}`}
                  />
                ))}
              </div>
              
              <div className="flex space-x-2">
                <button
                  onClick={prevTestimonial}
                  className="p-2 rounded-full border border-gray-300 hover:bg-gray-100 transition-colors"
                  aria-label="Previous testimonial"
                >
                  <ChevronLeft className="w-5 h-5 text-gray-700" />
                </button>
                <button
                  onClick={nextTestimonial}
                  className="p-2 rounded-full border border-gray-300 hover:bg-gray-100 transition-colors"
                  aria-label="Next testimonial"
                >
                  <ChevronRight className="w-5 h-5 text-gray-700" />
                </button>
              </div>
            </div>
          </div>
          
          <div className="mt-10 text-center">
            <p className="text-gray-600 mb-4">
              Would you like to share your experience with our services?
            </p>
            <a 
              href="#share-story" 
              className="inline-block bg-teal-600 hover:bg-teal-700 text-white px-6 py-3 rounded-lg transition-colors font-medium"
            >
              Share Your Story
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};