import React from 'react';

export const TeamSection = () => {
  const team = [
    {
      id: 1,
      name: "Dr. Sarah Johnson",
      role: "Medical Director & HIV Specialist",
      bio: "Board-certified in Infectious Disease with over 15 years of experience in HIV care.",
      image: "https://images.pexels.com/photos/5214995/pexels-photo-5214995.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      id: 2,
      name: "Dr. Michael Chen",
      role: "Infectious Disease Physician",
      bio: "Specializes in managing complex HIV cases and co-infections.",
      image: "https://images.pexels.com/photos/5327656/pexels-photo-5327656.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      id: 3,
      name: "Lisa Rodriguez, NP",
      role: "Nurse Practitioner",
      bio: "Focused on HIV prevention and PrEP management with a compassionate approach.",
      image: "https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      id: 4,
      name: "James Wilson",
      role: "Clinical Social Worker",
      bio: "Provides counseling and connects patients with essential support services.",
      image: "https://images.pexels.com/photos/8460157/pexels-photo-8460157.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      id: 5,
      name: "Dr. Aisha Williams",
      role: "Psychiatrist",
      bio: "Specializes in mental health care for individuals living with HIV.",
      image: "https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    },
    {
      id: 6,
      name: "Robert Thompson",
      role: "Nutritionist",
      bio: "Expert in nutrition strategies to support immune health and medication efficacy.",
      image: "https://images.pexels.com/photos/5998470/pexels-photo-5998470.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
    }
  ];

  return (
    <section id="team" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">Our Care Team</h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            Meet our compassionate team of healthcare professionals dedicated to providing comprehensive, 
            personalized care for individuals living with HIV.
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {team.map((member) => (
            <div 
              key={member.id} 
              className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="h-64 overflow-hidden">
                <img 
                  src={member.image} 
                  alt={member.name} 
                  className="w-full h-full object-cover object-center"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-800">{member.name}</h3>
                <p className="text-blue-600 font-medium mb-2">{member.role}</p>
                <p className="text-gray-600">{member.bio}</p>
                <button className="mt-4 text-blue-600 hover:text-blue-800 font-medium">
                  View Profile
                </button>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 bg-blue-50 rounded-xl p-8 text-center">
          <h3 className="text-xl font-semibold mb-4">Join Our Care Team</h3>
          <p className="text-gray-600 max-w-3xl mx-auto mb-6">
            We're always looking for compassionate healthcare professionals who are dedicated to 
            providing exceptional care for people living with HIV.
          </p>
          <a 
            href="#careers" 
            className="inline-block bg-white border border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-6 py-3 rounded-lg transition-colors font-medium"
          >
            View Open Positions
          </a>
        </div>
      </div>
    </section>
  );
};