import React from 'react';

export const Services = () => {
  const services = [
    {
      id: 1,
      title: "HIV Testing & Diagnosis",
      description: "Confidential testing services with rapid results and professional counseling before and after testing.",
      image: "https://images.pexels.com/photos/4226119/pexels-photo-4226119.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: 2,
      title: "Antiretroviral Therapy",
      description: "State-of-the-art medication regimens tailored to your specific needs to effectively manage HIV.",
      image: "https://images.pexels.com/photos/5910953/pexels-photo-5910953.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: 3,
      title: "PrEP & PEP Services",
      description: "Pre-exposure and post-exposure prophylaxis services to prevent HIV infection in high-risk individuals.",
      image: "https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: 4,
      title: "Mental Health Support",
      description: "Specialized counseling and psychiatric services to address the mental health aspects of living with HIV.",
      image: "https://images.pexels.com/photos/7176026/pexels-photo-7176026.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: 5,
      title: "Nutrition Counseling",
      description: "Personalized nutritional guidance to support your immune system and overall health.",
      image: "https://images.pexels.com/photos/4050990/pexels-photo-4050990.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    },
    {
      id: 6,
      title: "Case Management",
      description: "Dedicated case managers to help coordinate your care and connect you with essential resources.",
      image: "https://images.pexels.com/photos/6647037/pexels-photo-6647037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
    }
  ];

  return (
    <section id="services" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">Our Comprehensive Services</h2>
          <p className="text-gray-600 max-w-3xl mx-auto">
            We offer a wide range of specialized services designed to provide complete care for individuals living with HIV, as well as prevention services for those at risk.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div 
              key={service.id} 
              className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="h-48 overflow-hidden">
                <img 
                  src={service.image} 
                  alt={service.title} 
                  className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
                <a 
                  href={`#service-${service.id}`} 
                  className="inline-block mt-4 text-blue-600 hover:text-blue-800 font-medium"
                >
                  Learn more →
                </a>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <a 
            href="#appointment" 
            className="inline-flex items-center bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-full transition-colors"
          >
            View All Services
          </a>
        </div>
      </div>
    </section>
  );
};