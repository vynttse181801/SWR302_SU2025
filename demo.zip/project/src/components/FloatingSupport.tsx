import React, { useState } from 'react';
import { MessageCircle, X, LifeBuoy, Clock, Calendar } from 'lucide-react';

export const FloatingSupport = () => {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div className="fixed bottom-6 right-6 z-50">
      {isOpen && (
        <div className="bg-white rounded-lg shadow-xl mb-4 w-80 overflow-hidden animate-fade-in">
          <div className="bg-blue-600 px-4 py-3 flex justify-between items-center">
            <h3 className="text-white font-medium">Support & Resources</h3>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-white hover:text-blue-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <div className="p-4">
            <p className="text-gray-600 text-sm mb-4">
              How can we help you today? Select an option below or message us directly.
            </p>
            
            <div className="space-y-2 mb-4">
              <a 
                href="#appointment"
                className="flex items-center p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                  <Calendar className="w-4 h-4 text-blue-600" />
                </div>
                <div>
                  <span className="block text-sm font-medium text-gray-800">Schedule Appointment</span>
                  <span className="text-xs text-gray-500">Book a visit or telehealth call</span>
                </div>
              </a>
              
              <a 
                href="#emergency"
                className="flex items-center p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center mr-3">
                  <LifeBuoy className="w-4 h-4 text-red-600" />
                </div>
                <div>
                  <span className="block text-sm font-medium text-gray-800">Emergency Support</span>
                  <span className="text-xs text-gray-500">24/7 crisis assistance</span>
                </div>
              </a>
              
              <a 
                href="#hours"
                className="flex items-center p-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <div className="w-8 h-8 bg-teal-100 rounded-full flex items-center justify-center mr-3">
                  <Clock className="w-4 h-4 text-teal-600" />
                </div>
                <div>
                  <span className="block text-sm font-medium text-gray-800">Clinic Hours</span>
                  <span className="text-xs text-gray-500">View our operating hours</span>
                </div>
              </a>
            </div>
            
            <div className="pt-3 border-t border-gray-200">
              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-lg py-2 transition-colors text-sm">
                Start Live Chat
              </button>
            </div>
          </div>
        </div>
      )}
      
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-colors ${
          isOpen ? 'bg-red-600 hover:bg-red-700' : 'bg-blue-600 hover:bg-blue-700'
        }`}
      >
        {isOpen ? (
          <X className="w-6 h-6 text-white" />
        ) : (
          <MessageCircle className="w-6 h-6 text-white" />
        )}
      </button>
    </div>
  );
};