import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { Resources } from './components/Resources';
import { AppointmentSection } from './components/AppointmentSection';
import { TeamSection } from './components/TeamSection';
import { Testimonials } from './components/Testimonials';
import { FAQ } from './components/FAQ';
import { Footer } from './components/Footer';
import { FloatingSupport } from './components/FloatingSupport';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main>
        <Hero />
        <Services />
        <Resources />
        <AppointmentSection />
        <TeamSection />
        <Testimonials />
        <FAQ />
      </main>
      <Footer />
      <FloatingSupport />
    </div>
  );
}

export default App;